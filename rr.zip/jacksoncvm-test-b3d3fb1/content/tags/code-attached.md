---
title: code-attached
description: Articles for code-attached
---

* [Grails](/frameworks/java/spring/grails.html) - Grails Application Development with Cloud Foundry
* [Spring](/frameworks/java/spring/spring.html) - Spring Application Development with Cloud Foundry
* [Scala](/frameworks/scala/scala.html) - Scala Application Development with Cloud Foundry
* [Using RabbitMQ with Ruby](/services/rabbitmq/ruby-rabbitmq.html) - Ruby Development with the RabbitMQ Service
* [Using RabbitMQ with Spring](/services/rabbitmq/spring-rabbitmq.html) - Getting Started with the RabbitMQ Service from a Spring Application
* [Box Integration](/tools/gallery/box.html) - Sample Application Deployment via Gallery
