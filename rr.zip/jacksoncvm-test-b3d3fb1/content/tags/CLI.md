---
title: CLI
description: Articles for CLI
---

* [VMC Installation](/tools/vmc/installing-vmc.html) - Installing the Command-Line Interface (vmc)
* [VMC Quick Reference](/tools/vmc/vmc-quick-ref.html) - All of the vmc commands available
