---
title: sinatra
description: Articles for sinatra
---

* [Ruby, Rails, Sinatra](/frameworks/ruby/ruby-rails-sinatra.html) - Working with Ruby, Rails and Sinatra
* [Creating a Simple Ruby Application](/frameworks/ruby/ruby-simple.html) - Create a Simple Ruby Application and Deploy to Cloud Foundry
* [Sinatra](/frameworks/ruby/sinatra.html) - Sinatra Development with Cloud Foundry
* [Using MongoDB with Ruby](/services/mongodb/ruby-mongodb.html) - Ruby Development with the MongoDB Service
* [Using MySQL with Ruby](/services/mysql/ruby-mysql.html) - Ruby Development with the MySQL Service
