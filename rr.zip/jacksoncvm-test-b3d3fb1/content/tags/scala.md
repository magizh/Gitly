---
title: scala
description: Articles for scala
---

* [Play Java](/frameworks/play/scala-getting-started.html) - Play Scala Application Development with Cloud Foundry
* [Lift](/frameworks/scala/lift.html) - Using Lift on Cloud Foundry
* [Scala](/frameworks/scala/scala.html) - Scala Application Development with Cloud Foundry
