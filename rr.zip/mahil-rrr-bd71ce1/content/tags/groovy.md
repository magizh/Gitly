---
title: groovy
description: Articles for groovy
---

* [Grails](/frameworks/java/spring/grails.html) - Grails Application Development with Cloud Foundry
* [Using MySQL with Grails](/services/mysql/grails-mysql.html) - Grails Development with the MySQL Cloud Foundry Service
