---
title: mcf
description: Articles for mcf
---

* [Installing Micro Cloud Foundry](/infrastructure/micro/installing-mcf.html) - Get the Micro Cloud Foundry VM Installed and Running
* [Micro Cloud Foundry](/infrastructure/micro/mcf.html) - Get Started with the Micro Cloud Foundry VM
* [Using Micro Cloud Foundry](/infrastructure/micro/using-mcf.html) - Using the Micro Cloud Foundry Console
