---
title: Micro Cloud Foundry
description: Get Started with the Micro Cloud Foundry VM
tags:
    - mcf
---

These documents will help you get started with the Micro Cloud Foundry VM:

+ [Installing Micro Cloud Foundry](/infrastructure/micro/installing-mcf.html)
+ [Using Micro Cloud Foundry](/infrastructure/micro/using-mcf.html)

