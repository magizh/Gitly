---
title: Redis
description: Using the Redis Service on Cloud Foundry
tags:
    - redis
---

The following resource will help you get started using the Redis service on Cloud Foundry:

+ [Ruby Application Development with the Redis Service](/services/redis/ruby-redis.html)